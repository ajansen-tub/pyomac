Toolbox for operational modal analysis in python.

# ToDo:

+ [ ] add comments and function descriptions to code
+ [ ] write faster implementation of ssi_cov
+ [ ] publish on pypi
+ [ ] description of example
+ [ ] ...



